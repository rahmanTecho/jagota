class Sales {
//   constructor(private readonly salesService: SalesService) {}
}
