interface SalesData {
  year: number;
  margin: string;
  dist: number;
  budgetPercentage: string;
  value: number;
  growth: string;
  gap: string;
}
