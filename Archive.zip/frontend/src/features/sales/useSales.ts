import { useState } from "react";
import { API_URL } from "../../common/constants";
import useFetch from "../../common/hooks/useFetch";

type SalesData = {
  year: number;
  margin: string;
  dist: number;
  budgetPercentage: string;
  value: number;
  growth: string;
  gap: string;
};

const useSales = () => {
  const [filter, setFilter] = useState<{ from?: number; to?: number }>({});

  // Construct the URL based on the filter
  const url = `${API_URL}/sales${
    filter.from && filter.to ? `?from=${filter.from}&to=${filter.to}` : ""
  }`;

  // Use your custom hook
  const { data: fetchedData, loading, error } = useFetch<SalesData[]>(url);

  // Group data by year
  const groupedData = fetchedData
    ? Object.values(fetchedData).reduce(
        (acc: { [key: string]: SalesData[] }, curr: SalesData) => {
          const year = curr.year.toString();
          if (!acc[year]) {
            acc[year] = [];
          }
          acc[year].push(curr);
          return acc;
        },
        {}
      )
    : {};

  // Function to update the filter
  const updateSalesData = (from?: number, to?: number) => {
    setFilter({ from, to });
  };

  return { data: groupedData, loading, error, updateSalesData };
};

export default useSales;
